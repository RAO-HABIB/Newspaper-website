export function GET(request){
    return new Response('hello')
}

// export function POST(request){
//     return new Response('hello')
// }