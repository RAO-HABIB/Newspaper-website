export default function LoadingNewsItem() {
  return <p>Loading news item ...</p>
}