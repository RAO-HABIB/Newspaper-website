export default function NewsLoading() {
  return <p>Loading...</p>;
}