export default function loadingNews() {
  return (
    <p>Loading ....</p> 
)
}
